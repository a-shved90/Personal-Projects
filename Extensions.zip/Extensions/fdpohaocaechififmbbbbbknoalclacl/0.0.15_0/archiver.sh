#!/usr/bin/env bash
git archive -o full-page-screen-capture.zip HEAD
